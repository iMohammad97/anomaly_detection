
import numpy as np


class WalkForward:

    def __init__(self, name="Walk Forwarder"):
        self.name = name

    def _check_train_test_keys(self, dict_of_train_test_tuples):
        
        if 'train' not in dict_of_train_test_tuples or 'test' not in dict_of_train_test_tuples:
            raise KeyError(f"Missing 'train' or 'test' key in dictionary")


    def _check_target_weights_exists(self, test_weights_df):
        
        if test_weights_df is None:
            raise ValueError("test_weights_df is None, it should not be None if you want to backtest (fill target weghter func).")
    
    def _check_prices_exist(self, prices_df ):
        if prices_df is None:
            raise ValueError("prices_df is None, it should not be None if you want to backtest ")
    
        
    def run_prediction(self, X, y,  list_of_train_test_dicts, train_func, test_func, validation_func=None,
             train_hyperparameters_dict:dict=None ):
        ## each range in train tuple or test tuple must be inclusive range in both start and end
        ## also you must pass index of the dataframe which we call it by .loc; not by .iloc

        y_predicted_test_information, y_actual_test_information = [], []

        for dict_of_train_test in list_of_train_test_dicts:
            self._check_train_test_keys(dict_of_train_test)
            
            start_train_index, end_train_index = dict_of_train_test['train']
            start_test_index, end_test_index = dict_of_train_test['test']
            
            X_train , y_train = X.loc[start_train_index:end_train_index], y.loc[start_train_index:end_train_index]
            X_test , y_test =  X.loc[start_test_index:end_test_index], y.loc[start_test_index:end_test_index]

            ## Train and validation
            if (validation_func is not None) and ('validation' in dict_of_train_test):
                start_val_index, end_val_index  = dict_of_train_test['validation']
                X_valid , y_valid =  X.loc[start_val_index:end_val_index], y.loc[start_val_index:end_val_index]

                optimized_hyperparameters_dict = validation_func(X_train, y_train, X_valid, y_valid)
                fitted_model = train_func(X_train, y_train, optimized_hyperparameters_dict)

            else: 
                fitted_model = train_func(X_train, y_train, train_hyperparameters_dict)
            
            # Test
            y_test_predicted_values = test_func(fitted_model, X_test)
            y_predicted_test_information.append((X_test.index, y_test_predicted_values))
            y_actual_test_information.append((X_test.index, y_test))
        
        return y_predicted_test_information, y_actual_test_information





class ExpandingWalkForward(WalkForward):

    def __init__(self, name = "Expanding_Walkforwarder", step_period = 1  , num_embargo_samples=0, 
                 num_shift_smaples_between_train_and_test =0 ):
        super().__init__(name)
        self.step_period = step_period
        self.num_embargo_samples = num_embargo_samples
        self.num_shift_smaples_between_train_and_test = num_shift_smaples_between_train_and_test


    def run_prediction(self, start_testing_point_index, X, y, train_func,  test_func, validation_func=None,
                    train_hyperparameters_dict:dict=None):

        list_of_train_test_dicts = []

        starting_point_int_index = X.index.get_loc(start_testing_point_index)
        
        for i in range(starting_point_int_index, len(X), self.step_period):
            max_train_index = max(0 , i-1-self.num_shift_smaples_between_train_and_test)

            if ((i + self.num_embargo_samples) > (len(X)-1)):
                break
            elif ((i + self.num_embargo_samples + self.step_period)  >  (len(X)-1)):
                start_end_train_indexes  =  (X.index[0],  X.index[max_train_index])
                # should conclude just until the range : self.X.index[-1]
                start_end_test_indexes  = (X.index[i + self.num_embargo_samples], X.index[-1])
                list_of_train_test_dicts.append({'train': start_end_train_indexes, 'test': start_end_test_indexes})
            else:
                # should not include : i- -self.num_shift_smaples_between_train_and_test
                start_end_train_indexes = (X.index[0],  X.index[max_train_index])
                # should not include : i + num_embargo_samples + step_period
                start_end_test_indexes =  (X.index[i + self.num_embargo_samples],  
                                           X.index[i + self.num_embargo_samples + self.step_period-1])     
                list_of_train_test_dicts.append({'train': start_end_train_indexes, 'test': start_end_test_indexes})

        # Call the run method of the WalkForward class here
        y_predicted_test_information, y_actual_test_information  =\
            super().run_prediction(X= X, y=y, list_of_train_test_dicts=list_of_train_test_dicts,
                        train_func=train_func, test_func=test_func, validation_func=validation_func,
                        train_hyperparameters_dict = train_hyperparameters_dict)

        return y_predicted_test_information, y_actual_test_information 




class RollingWalkForward(WalkForward):

    def __init__(self, name = "Rolling_Walkforwarder", window_size=30, step_period = 1  , num_embargo_samples=0,
                 num_shift_smaples_between_train_and_test=0):
        super().__init__(name)
        self.window_size = window_size
        self.step_period = step_period
        self.num_embargo_samples = num_embargo_samples
        self.num_shift_smaples_between_train_and_test = num_shift_smaples_between_train_and_test
  

    def run_prediction(self, start_testing_point_index, X, y, train_func,  test_func, validation_func=None,
            train_hyperparameters_dict:dict=None ):

        list_of_train_test_dicts = []
        starting_point_int_index = X.index.get_loc(start_testing_point_index)
        
        for i in range(starting_point_int_index, len(X), self.step_period):
            start_window = max(0,i-self.window_size+1)
            max_train_index = max(start_window , i-1-self.num_shift_smaples_between_train_and_test)

            if ((i + self.num_embargo_samples) > (len(X)-1)):
                break
            elif ((i + self.num_embargo_samples + self.step_period)  > (len(X)-1)):
                start_end_train_indexes  =  (X.index[start_window],  X.index[max_train_index])
                # should conclude just until the range : self.X.index[-1]
                start_end_test_indexes  = (X.index[i + self.num_embargo_samples], X.index[-1])
                list_of_train_test_dicts.append({'train': start_end_train_indexes, 'test': start_end_test_indexes})
            else:
                # should not conclude : i 
                start_end_train_indexes = (X.index[start_window],  X.index[max_train_index])
                # should not conclude : i + num_embargo_samples + step_period
                start_end_test_indexes =  (X.index[i + self.num_embargo_samples],  
                                           X.index[i + self.num_embargo_samples + self.step_period-1])
                list_of_train_test_dicts.append({'train': start_end_train_indexes, 'test': start_end_test_indexes})

        # Call the run method of the WalkForward class here
        y_predicted_test_information, y_actual_test_information   =\
            super().run_prediction(X= X, y=y, list_of_train_test_dicts=list_of_train_test_dicts,
                        train_func=train_func, test_func=test_func, validation_func=validation_func,
                        train_hyperparameters_dict = train_hyperparameters_dict)

        return  y_predicted_test_information, y_actual_test_information 


