import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


from .backtest import Backtest, run
from .core import Strategy
from . import algos


def get_prophet_taget_weights(prices_df):

    tw_df = (prices_df*0).copy()
    max_columns = prices_df.pct_change().fillna(0).idxmax(axis=1)  
    
    for index, value in max_columns.items():
        tw_df.loc[index, value] = 1
    
    tw_df = tw_df.shift(-1)
    return tw_df.astype(float)
     

def plot_ranking_pi_chart(returns_df, figsize=(6,6) ):
    ranks_df = returns_df.rank(axis=1, ascending =False, method='min' )
    
    # Plotting pie charts for each column's ranks
    fig, axes = plt.subplots(nrows=len(ranks_df.columns), figsize=(figsize[0], figsize[1] * len(ranks_df.columns)))

    for col, ax in zip(ranks_df.columns, axes):
        rank_counts = ranks_df[col].value_counts().sort_index()
        ax.pie(rank_counts, labels=rank_counts.index, autopct='%1.1f%%', startangle=90)
        ax.set_title(f'Pie Chart of Ranks for Strategy "{col}"')

    plt.tight_layout()
    plt.show()
    return ranks_df



def run_target_weight_based_backtest(tw_dfs, names , prices_df, rf=0.2, metrics_group='main', plot_equity_progression=False,
                    plot_yearly_returns=False, plot_security_weights=False, get_turnover=False, rebalance_days=None,
                    **additional_backtester_args):

        
        backtests = []
        assert len(names)==len(tw_dfs)

        for i , tw_df in enumerate(tw_dfs):
            assert len(prices_df)==len(tw_df)
            
            if rebalance_days:
                strat = Strategy(names[i], [
                            algos.RunOnDate(*rebalance_days),
                            algos.WeighTarget(tw_df),
                            algos.Rebalance()])
            else:
                strat = Strategy(names[i], [
                            algos.RunOnDate(*tw_df.index),
                            algos.WeighTarget(tw_df),
                            algos.Rebalance()])

            if "initial_capital"  not in  additional_backtester_args: 
                additional_backtester_args["initial_capital"] = float(10**(round(np.log10(prices_df.max().max())+1)))
            

            # now we create the Backtest
            backtest_obj = Backtest(strat, prices_df, **additional_backtester_args)
            backtests.append(backtest_obj)

        # and let's run it!



        result , stats = run(*backtests, rf = rf, metrics_group=metrics_group ,plot_equity_progression=plot_equity_progression,
                    plot_yearly_returns=plot_yearly_returns, plot_security_weights=plot_security_weights,
                      get_turnover=get_turnover)

        
 
        return result, stats




def run_all_subsets_backtest(tw_dfs, names, prices_df, metric='cagr', stride = 1, n_period_freq=120,
                             figsize=(6,6), plot_ranks_pie_chart=True, **additional_backtester_args):
        
        ranks_df = pd.DataFrame(columns= names)
        metrics_df = pd.DataFrame(columns= names)

        assert len(names)==len(tw_dfs)

        for j in range(0, len(prices_df)-n_period_freq, stride):
            specific_tw_df_list = []

            for i , tw_df in enumerate(tw_dfs):
                # assert len(prices_df)==len(tw_df)

                specific_prices_df = prices_df.iloc[j:j+n_period_freq]
                specific_tw_df = tw_df.iloc[j:j+n_period_freq]
                specific_tw_df_list.append(specific_tw_df)
        
            _, stats = run_target_weight_based_backtest(names=names,
                                                        prices_df=specific_prices_df,
                                                        tw_dfs=specific_tw_df_list,
                                                        **additional_backtester_args)

            metrics_df.loc[j, :] = stats.loc[metric].values
                
        ranks_df = metrics_df.rank(axis=1, ascending =False, method='average')

        if plot_ranks_pie_chart:
            # Plotting pie charts for each column's ranks
            fig, axes = plt.subplots(nrows=len(ranks_df.columns), figsize=(figsize[0], figsize[1] * len(ranks_df.columns)))

            for col, ax in zip(ranks_df.columns, axes):
                rank_counts = ranks_df[col].value_counts().sort_index()
                ax.pie(rank_counts, labels=rank_counts.index, autopct='%1.1f%%', startangle=90)
                ax.set_title(f'Pie Chart of Ranks for Strategy "{col}"')

            plt.tight_layout()
            plt.show()

        return metrics_df, ranks_df


def apply_highlighting_stats(stats_df, decimal_places=2):
    
    def highlight_values(row):
        negative_variables = ["max_drawdown", "yearly_vol", "var-0.95" , "num_transactions"]
        sorted_vals = sorted(row.values)

        if row.name in negative_variables:
            max_val = sorted_vals[1]
            second_max_val = sorted_vals[0]
            second_min_val = sorted_vals[-2]
            min_val = second_min_val = sorted_vals[-1]
            
        else:
            max_val = sorted_vals[-1]
            min_val = sorted_vals[0]
            second_max_val = sorted_vals[-2]
            second_min_val = sorted_vals[1]

        colors = []
        for v in row:
            if v == max_val:
                colors.append('background-color: green')
            elif v == min_val:
                colors.append('background-color: red')
            elif v == second_max_val:
                colors.append('background-color: yellow')
            elif v == second_min_val:
                colors.append('background-color: lightcoral')
            else:
                colors.append('')

        return pd.Series(colors, index=row.index)
    
    def convert_to_decimals(x, decimal_places):
        if isinstance(x , float):
            return f'{x:.{decimal_places}f}'
        else : 
            return x


    return stats_df.applymap(lambda x: convert_to_decimals(x, decimal_places)).style.apply(highlight_values, axis=1)

    