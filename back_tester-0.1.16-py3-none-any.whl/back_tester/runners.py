
import pandas as pd

from back_tester.backtest import Result
from .metrics import *


VAR_NAME = "var-0.95"
REGRET_COST_NAME = "regret_cost"
MEAN_BASED_SORTINO = "mean_based_sortino"
NUM_TRANSACTIONS = "num_transactions"

MAIN_METRICS = ["total_return", "cagr", "max_drawdown", "yearly_sharpe", "yearly_sortino", "yearly_vol", VAR_NAME, 
                 MEAN_BASED_SORTINO, NUM_TRANSACTIONS]#


def run(*backtests, rf = 0.0, metrics_group="main", plot_equity_progression=False, plot_yearly_returns=False,
         plot_security_weights=False, get_turnover=False):
    """
    Runs a series of backtests and returns a Result
    object containing the results of the backtests.

    Args:
        * backtest (*list): List of backtests.

    Returns:
        Result Object, Stats dataframe

    """


    def extend_stats(results, rf):

        results.set_riskfree_rate(rf)
        
        value_at_risk = ValueAtRisk(name = VAR_NAME) 
        regret_cost =  RegretCost(name = REGRET_COST_NAME)
        mean_based_sortino_ratio = MeanBasedSortinoRatio(name=MEAN_BASED_SORTINO, frequency='Y', yealy_MAR = 0.1, rf = 0.2)
        num_transactions = NumTransactions(name =NUM_TRANSACTIONS  )
        
        value_at_risk_stat_df = value_at_risk.calculate(strategy_prices_df = results.prices)
        mean_based_sortino_ratio_df = mean_based_sortino_ratio.calculate(strategy_prices_df = results.prices)
        num_transactions = num_transactions.calculate(result_object = results)
        
        regret_costs_df = pd.DataFrame(index = [REGRET_COST_NAME])
        
        for name, backtest in results.backtests.items():
            regret_cost_df = regret_cost.calculate(asset_prices_df = backtest.data,
                                                   strategy_prices_df = results.prices[[name]])
            regret_costs_df[name] =  regret_cost_df 

        results.stats = pd.concat([results.stats  , regret_costs_df, value_at_risk_stat_df, mean_based_sortino_ratio_df,
                                    num_transactions] , axis=0)

        return results


    for bkt in backtests:
        bkt.run()

    
    results = Result(*backtests)
    extend_stats(results, rf= rf)

    if plot_equity_progression:
        results.plot()

    if plot_yearly_returns:
        results.plot_yearly_returns(backtests = list(results.backtests.keys()), width=100)

    if plot_security_weights:
        for backtest_name, _ in results.backtests.items():
            results.plot_security_weights(backtest = backtest_name )
        
    if get_turnover:
        print("Monthly Turnover :")
        print('---------------')
        print(results.get_turnover(backtests=[0,1], frequency='M').to_string())
        print('---------------')


    if metrics_group=="main":
        return results, results.stats.loc[MAIN_METRICS]
    else: 
        return results, results.stats


def print_salam():
    print("salam2")

   
