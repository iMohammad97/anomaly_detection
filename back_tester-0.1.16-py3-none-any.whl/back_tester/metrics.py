import pandas as pd
import numpy as np


class Metric():
    def __init__(self, name):
        self.name = name


class RegretCost(Metric):
    def __init__(self, name = "Regret Cost" ):
        super(RegretCost, self).__init__(name = name)
 

    def calculate(self, asset_prices_df , strategy_prices_df):
        
        strategy_returns_df = strategy_prices_df.to_returns().fillna(0)
        
        asset_returns_df = asset_prices_df.to_returns().fillna(0)
        ideal_portfolio_returns_df = asset_returns_df.max(axis=1).to_frame()
        ideal_portfolio_returns_df.columns = strategy_returns_df.columns
    
        self.value = ((1+(strategy_returns_df - ideal_portfolio_returns_df)**2).prod()-1).to_frame().T
        self.value.index = [self.name]
        
        return self.value
    


class ValueAtRisk(Metric):
    def __init__(self, name = "VAR" , confidence_level = 0.95):
        super(ValueAtRisk, self).__init__(name = name )
        self.confidence_level = confidence_level
    
    def calculate(self, strategy_prices_df):
    
        returns_df = strategy_prices_df.to_returns().fillna(0)
        self.value = returns_df.quantile(1 - self.confidence_level).to_frame().T
        self.value.index = [self.name]
        return self.value



class MARBasedSortinoRatio(Metric):
    def __init__(self, yealy_MAR , name = "MAR_based_sortino", frequency='Y', rf = 0.2):
        super(MARBasedSortinoRatio, self).__init__(name = name )
        if yealy_MAR is None : 
            yealy_MAR = rf
        self.yealy_MAR = yealy_MAR
        self.frequency = frequency
        self.rf = rf


    def calculate(self, strategy_prices_df):
        
        total_return = ((strategy_prices_df.iloc[-1] - strategy_prices_df.iloc[0])/ strategy_prices_df.iloc[0]).to_frame().T
        days_difference = (strategy_prices_df.index[-1] - strategy_prices_df.index[0]).days


        if self.frequency =='Y':
            days_per_year = 365
            summarized_frequency_related_return = (total_return + 1.0)**(1/(days_difference/days_per_year))-1.0
            frequency_related_return_df = strategy_prices_df.resample(self.frequency).agg(lambda x: (x.iloc[-1]- x.iloc[0])/(x.iloc[0]))
            downside_std = frequency_related_return_df[frequency_related_return_df < self.yealy_MAR].std()

        elif self.frequency =='M':
            days_per_month = 30
            summarized_frequency_related_return = (total_return + 1.0)**(1/(days_difference/days_per_month))-1.0
            frequency_related_return_df = strategy_prices_df.resample(self.frequency).agg(lambda x: (x.iloc[-1]- x.iloc[0])/(x.iloc[0]))
            
            monthly_MAR = (self.yealy_MAR + 1.0)**(1/(days_difference/days_per_month))-1.0
            downside_std = frequency_related_return_df[frequency_related_return_df < monthly_MAR].std()
        
        elif self.frequency =='D':
            summarized_frequency_related_return = (total_return + 1.0)**(1/(days_difference))-1.0
            frequency_related_return_df = strategy_prices_df.resample(self.frequency).agg(lambda x: (x.iloc[-1]- x.iloc[0])/(x.iloc[0]))
            
            daily_MAR = (self.yealy_MAR + 1.0)**(1/(days_difference))-1.0
            downside_std = frequency_related_return_df[frequency_related_return_df < daily_MAR].std()
        
        
        self.value = ((summarized_frequency_related_return - self.rf)/downside_std)
        self.value.index = [self.name]        
        self.value.columns = strategy_prices_df.columns
        
        return self.value


class NumTransactions(Metric):
    def __init__(self, name = "num_transactions"):
        super(NumTransactions, self).__init__(name = name )


    def calculate(self, result_object):
        from .backtest import Result
        if isinstance(result_object, Result) : 

            num_transaction_dict = {}
            for name, backtest in result_object.backtests.items():
                num_distinct_transaction_dates = len(result_object.get_transactions(strategy_name=name).index.get_level_values(0).unique())
                num_transaction_dict[name] = num_distinct_transaction_dates

            self.value = pd.DataFrame(data = num_transaction_dict , index= [self.name] )
        else:
            raise TypeError("result_object is not an instance of Result class")
        
        return self.value
    

class PBO(Metric):
    def __init__(self, name = "pbo"):
        super(PBO, self).__init__(name = name ) 
    

    def calculate(self, results_df):

        ranks_df = results_df.rank(axis=1, ascending =False, method='average' )
        normalized_df = ranks_df/(len(ranks_df.columns) +1)
        res = 1- normalized_df.apply(lambda x: np.log(x/(1-x)))\
            .applymap(lambda x:  1/len(results_df) if x<=0 else 0).sum().sort_values()

        return res


