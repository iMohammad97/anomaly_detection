
## third parties
import numpy as np
from itertools import combinations

from .backtest import run as run_backtest
import pandas as pd
from joblib import Parallel, delayed
from .walk_forward import  ExpandingWalkForward
from .utilities import run_target_weight_based_backtest

def _run_trial(trial, new_X, new_y, re_arranged_prices_df, start_testing_point_index,  train_func, test_func, validation_func,
                train_hyperparameters_dict , run_just_backtest, target_weighter_func, walk_forwarder, strategy_base_name, rf,
                metrics_group, additional_weighting_data):
        
        y_predicted_test_information = None
        strategy_name = "{} Path {}".format(strategy_base_name, trial)
        
        if not run_just_backtest:
            y_predicted_test_information, _ = \
                    walk_forwarder.run_prediction(start_testing_point_index=start_testing_point_index, X=new_X, y=new_y,
                                                train_func=train_func, test_func=test_func, validation_func=validation_func,
                                                train_hyperparameters_dict=train_hyperparameters_dict)      

        
        additional_weighting_data["prices_df"] = re_arranged_prices_df

  
        test_weights_df = target_weighter_func(y_predicted_test_information, **additional_weighting_data)

        result, stats = run_target_weight_based_backtest(tw_dfs=[test_weights_df], names=[strategy_name] , prices_df=re_arranged_prices_df, 
                                        rf = rf, metrics_group=metrics_group)

            
        return stats, test_weights_df, y_predicted_test_information

class CSCV():

    def __init__(self, X , y, prices_df, num_groups=16, train_pct =0.85 ):
        
        all_data_length = len(X)
        assert all_data_length >= num_groups

        self.X = X
        self.y = y
        self._check_prices_exist(prices_df)
        self.prices_df = prices_df

        self.num_all_indices = all_data_length
        self.num_groups = num_groups
        
        self._indices = list(range(all_data_length))
        self.group_size = int(all_data_length/num_groups)
        self._combinaions = combinations(range(num_groups), int(train_pct*num_groups))
        self.train_test_indices = self._give_train_test_indices()
        

    def _give_train_test_indices(self): 

        """
        This is a generator wich yields (train_indices, test_indices) in each call. you can use that in a way sth like this : 
        """
        train_test_indices = []

        for comb in self._combinaions:
            train_indices = []

            for x in list(comb):
                if x == self.num_groups-1:
                    ## because the last group is not necassarily have identical size to another groups
                    train_indices +=  list(np.array(range(self.num_all_indices - self.group_size*(self.num_groups-1))) + x*self.group_size)
                else:
                    train_indices +=  list(np.array(range(self.group_size)) + x*self.group_size ) 

            test_indices = sorted(list(set(self._indices) - set(train_indices)))

            train_test_indices.append((train_indices, test_indices))
        
        return train_test_indices
    

    def give_all_rearranged_data(self, artificial_date_freq='M'):

        all_combination_dfs = []

        for (train_indices , test_indices) in self.train_test_indices:
            
            X_train , X_test = self.X.iloc[train_indices], self.X.iloc[test_indices]
            y_train , y_test = self.y.iloc[train_indices], self.y.iloc[test_indices]            
            test_prices_df = self.prices_df.iloc[test_indices]
            
            new_X = pd.concat([X_train, X_test], axis=0)
            new_y = pd.concat([y_train, y_test], axis=0)
            
            ## correct X , y indexing 
            rearranged_X = self._index_new_dates(df = new_X , start_date = self.X.index[0] , 
                                                  artificial_date_freq = self.X.index.inferred_freq)

        
            rearranged_y = self._index_new_dates(df = new_y , start_date = self.y.index[0] , 
                                                  artificial_date_freq = self.y.index.inferred_freq)

            test_split_locations = self._find_split_points_indices(indices=test_indices)

            rearranged_test_prices_df = self._rearrange_prices_df(test_prices_df=test_prices_df, split_locations = test_split_locations)


            test_range_starting_point_index = rearranged_X.index[-len(test_indices)]

            rearranged_test_prices_df = self._index_new_dates(df = rearranged_test_prices_df , 
                                                            start_date = test_range_starting_point_index , 
                                                            artificial_date_freq = artificial_date_freq)


            all_combination_dfs.append(( rearranged_X, rearranged_y, rearranged_test_prices_df, test_range_starting_point_index))
        
        return all_combination_dfs


    def give_train_test_rearranged_data(self, artificial_date_freq='M') : 


        all_combination_dfs = []

        for (train_indices , test_indices) in self.train_test_indices:

            X_train , X_test = self.X.iloc[train_indices], self.X.iloc[test_indices]
            y_train , y_test = self.y.iloc[train_indices], self.y.iloc[test_indices]            
            test_prices_df = self.prices_df.iloc[test_indices]

            new_X = pd.concat([X_train, X_test], axis=0)
            new_y = pd.concat([y_train, y_test], axis=0)
            
            ## correct X , y indexing 
            rearranged_X = self._index_new_dates(df = new_X , start_date = self.X.index[0] , 
                                                  artificial_date_freq = self.X.index.inferred_freq)
        
            rearranged_y = self._index_new_dates(df = new_y , start_date = self.y.index[0] , 
                                                  artificial_date_freq = self.y.index.inferred_freq)

            split_locations = self._find_split_points_indices(indices=test_indices)

            rearranged_test_prices_df = self._rearrange_prices_df(test_prices_df=test_prices_df, split_locations = split_locations)

            test_range_starting_point_index = rearranged_X.index[-len(test_indices)]

            rearranged_test_prices_df = self._index_new_dates(df = rearranged_test_prices_df , 
                                                            start_date = test_range_starting_point_index , 
                                                            artificial_date_freq = artificial_date_freq)

            X_train , X_test = rearranged_X.iloc[0:len(train_indices)], rearranged_X.iloc[len(train_indices):]
            y_train , y_test = rearranged_y.iloc[0:len(train_indices)], rearranged_y.iloc[len(train_indices):]

            all_combination_dfs.append((X_train, y_train, X_test , y_test, rearranged_test_prices_df))
        
        return all_combination_dfs
    

    def _check_prices_exist(self, prices_df ):
        if prices_df is None:
            raise ValueError("prices_df is None, it should not be None if you want to backtest ")
    

    def _find_split_points_indices(self, indices ):
        
        split_locations = []
        for i in range(1, len(indices)):
            if (indices[i] - indices[i - 1]) > 1:
                split_locations.append(self.prices_df.index[indices[i]])  # Append the index of the first element in the pair
        return split_locations


    def _rearrange_prices_df(self, test_prices_df, split_locations  ):
        
        returns_df = (test_prices_df.pct_change()+1).fillna(1)
        returns_df.loc[split_locations] = 1.0
        rearranged_test_prices_df = returns_df.cumprod()
        return rearranged_test_prices_df

    def _index_new_dates(self, df, start_date, artificial_date_freq = 'M'):    

        # Define the start date for your artificial date range
        num_periods = len(df)  
        artificial_date_range = pd.date_range(start=start_date, periods=num_periods, freq= artificial_date_freq)
        df.index = artificial_date_range
        return df

class CSCVRunner():

    def __init__(self, prices_df, X=None, y=None,  num_groups=16 , train_pct=0.85):
        self.cscv = CSCV(X= X , y = y, prices_df = prices_df, num_groups= num_groups, train_pct = train_pct)

    def run(self, target_weighter_func, run_just_backtest=False, train_func=None, test_func=None,
            validation_func=None, walk_forwarder=ExpandingWalkForward(),
            train_hyperparameters_dict=None, strategy_base_name=" Strategy ", metrics_group='main', rf=0.2,
            verbose_frequency=20, artificial_date_freq='M', **additional_weighting_data):

        all_combination_dfs = self.cscv.give_all_rearranged_data(artificial_date_freq=artificial_date_freq)

        print("Starting processing...")

        args_list = [
            (trial, new_X, new_y, re_arranged_prices_df, test_range_starting_point_index,
             train_func, test_func, validation_func, train_hyperparameters_dict, run_just_backtest,
             target_weighter_func, walk_forwarder, strategy_base_name, rf, metrics_group, additional_weighting_data)
            for trial, (new_X, new_y, re_arranged_prices_df, test_range_starting_point_index) in enumerate(all_combination_dfs)
        ]

        results = Parallel(n_jobs=-1, verbose=verbose_frequency)(
            delayed(_run_trial)(*args) for args in args_list
        )


        print("Processing completed.")

        # Sort results by trial number
        # print(results)
        # all_results_sorted = sorted(results, key=lambda x: x['trial'])

        stats_sorted = [item[0] for item in results]
        test_weights_sorted = [item[1] for item in results]
        y_predictions_sorted = [item[2] for item in results]

        return stats_sorted, test_weights_sorted, y_predictions_sorted
 



