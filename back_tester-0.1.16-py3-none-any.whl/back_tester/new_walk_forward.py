import pandas as pd


class WalkForward:

    def __init__(self, X, y, train_func, test_func):
        self.X = X
        self.y = y
        self.train_func = train_func
        self.test_func = test_func


    def run(self, list_of_train_test_tuples):
        ## each range in train tuple or test tuple must be inclusive range in both start and end
        ## also you must pass index of the dataframe which we call it by .loc; not by .iloc
    
        y_predicted_test_dfs = []
        for i in range(len(list_of_train_test_tuples)):
            start_train_index, end_train_index = list_of_train_test_tuples[i][0]
            start_test_index, end_test_index = list_of_train_test_tuples[i][1]
            fitted_model = self.train_func(self.X.loc[start_train_index:end_train_index],
                                           self.y.loc[start_train_index:end_train_index])
            y_test_predicted_values = self.test_func(fitted_model, self.X.loc[start_test_index:end_test_index])
            y_predicted_test_df = pd.DataFrame(y_test_predicted_values, index=self.y.loc[start_test_index:end_test_index].index,
                                               columns=self.y.columns)
            y_predicted_test_dfs.append(y_predicted_test_df)
        
        return y_predicted_test_dfs


class ExpandingWalkForward(WalkForward):

    def __init__(self, X, y, train_func, test_func):
        super().__init__(X, y, train_func, test_func)


    def run(self, starting_point_index  , step_period = 1  , num_embargo_samples=0):

        list_of_train_test_tuples = []
        starting_point_int_index = list(self.X.index).index(starting_point_index)
        
        for i in range(starting_point_int_index, len(self.X), step_period):
            if (i + num_embargo_samples > len(self.X)-1):
                break
            elif (i + num_embargo_samples + step_period  >  len(self.X)-1):
                start_end_train_indexes  =  (self.X.index[0],  self.X.index[i-1])
                # should conclude just until the range : self.X.index[-1]
                start_end_test_indexes  = (self.X.index[i + num_embargo_samples], self.X.index[-1])
                list_of_train_test_tuples.append((start_end_train_indexes, start_end_test_indexes ))
            else:
                # should not conclude : i 
                start_end_train_indexes = (self.X.index[0],  self.X.index[i-1])
                # should not conclude : i + num_embargo_samples + step_period
                start_end_test_indexes =  (self.X.index[i + num_embargo_samples],  self.X.index[i + num_embargo_samples + step_period-1])     
                list_of_train_test_tuples.append((start_end_train_indexes, start_end_test_indexes ))

        # Call the run method of the WalkForward class here
        y_predicted_test_dfs = super().run(list_of_train_test_tuples)

        return y_predicted_test_dfs



class RollingWalkForward():

    def __init__(self, X, y, train_func, test_func):
        super().__init__(X, y, train_func, test_func)

  
    def run(self, starting_point_index  , window_size , step_period = 1  , num_embargo_samples=0):

        list_of_train_test_tuples = []
        starting_point_int_index = list(self.X.index).index(starting_point_index)
        
        for i in range(starting_point_int_index, len(self.X), step_period):
            start_window = max(0,i-window_size+1)
            
            if (i + num_embargo_samples > len(self.X)):
                break
            elif (i + num_embargo_samples + step_period  > len(self.X)):
                start_end_train_indexes  =  (start_window,  self.X.index[i-1])
                # should conclude just until the range : self.X.index[-1]
                start_end_test_indexes  = (self.X.index[i + num_embargo_samples], self.X.index[-1])
                list_of_train_test_tuples.append((start_end_train_indexes, start_end_test_indexes ))
            else:
                # should not conclude : i 
                start_end_train_indexes = (self.X.index[start_window],  self.X.index[i-1])
                # should not conclude : i + num_embargo_samples + step_period
                start_end_test_indexes =  (self.X.index[i + num_embargo_samples],  self.X.index[i + num_embargo_samples + step_period-1])
                list_of_train_test_tuples.append((start_end_train_indexes, start_end_test_indexes ))

        # Call the run method of the WalkForward class here
        y_predicted_test_dfs = super().run(list_of_train_test_tuples)

        return y_predicted_test_dfs

