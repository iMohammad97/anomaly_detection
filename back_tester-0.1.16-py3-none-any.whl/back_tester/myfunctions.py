
import pandas as pd

from bt.backtest import Result

def run(*backtests ):
    """
    Runs a series of backtests and returns a Result
    object containing the results of the backtests.

    Args:
        * backtest (*list): List of backtests.
        * rf : yearly risk free rate (int) or series of risk free rate prices 

    Returns:
        Result

    """
    # run each backtest

    def extend_stats(results):

        value_at_risk = ValueAtRisk(name = "VAR-0.95") 
        regret_cost =  RegretCost(name = "Regret Cost")
        value_at_risk_stat_df = value_at_risk.calculate(strategy_prices_df = results.prices)
        regret_cost_df = regret_cost.calculate(asset_prices_df = results.backtest_list[0].data,
                                               strategy_prices_df = results.prices)
        
        

        results.stats = pd.concat([results.stats  , value_at_risk_stat_df, regret_cost_df ] , axis=0)

        return results


    for bkt in backtests:
        bkt.run()

    results = Result(*backtests)

       
    extend_stats(results)

    return results



def print_salam():
    print("salam2")

   

class Metric():
    def __init__(self, name):
        self.name = name


class RegretCost(Metric):
    def __init__(self, name = "Regret Cost" ):
        super(RegretCost, self).__init__(name = name)
 

    
    def calculate(self, asset_prices_df , strategy_prices_df):
        strategy_returns_df = strategy_prices_df.to_returns().fillna(0)
        
        asset_returns_df = asset_prices_df.to_returns().fillna(0)
        ideal_portfolio_returns_df = asset_returns_df.max(axis=1).to_frame()
        ideal_portfolio_returns_df.columns = strategy_returns_df.columns
    
        self.value = ((1+(strategy_returns_df - ideal_portfolio_returns_df)**2).prod()-1).to_frame().T
        self.value.index = [self.name]
        
        return self.value
    


class ValueAtRisk(Metric):
    def __init__(self, name = "VAR" , confidence_level = 0.95):
        super(ValueAtRisk, self).__init__(name = name )
        self.confidence_level = confidence_level

    
    def calculate(self, strategy_prices_df):
        
        returns_df = strategy_prices_df.to_returns().fillna(0)
        self.value = returns_df.quantile(1 - self.confidence_level).to_frame().T
        self.value.index = [self.name]

        return self.value
        
